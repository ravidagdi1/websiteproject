const mongoose=require('mongoose')



const servicesSchema=mongoose.Schema({
    img:{
        type:String
    },
    title:{
        type:String,
        required:true
    },
    desc:{
        type:String,
        required:true
    },
    mdesc:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        required:true,
        default:new Date().toString()
    },
    status:{
        type:String,
        default:'Unpublished'
    }
})

module.exports=mongoose.model('service',servicesSchema)