const mongoose=require('mongoose')



const querySchema=mongoose.Schema({
    email:{
        type:String,
        required:true
    },
    query:{
        type:String,
        required:true
    },
    postedDate:{
        type:Date,
        default:new Date().toString(),
        required:true
    },
    status:{
        type:String,
        default:'Reply'
    }
})


module.exports=mongoose.model("query",querySchema)