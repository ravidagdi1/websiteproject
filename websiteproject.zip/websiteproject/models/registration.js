const mongoose=require('mongoose')//module


const regSchema=mongoose.Schema({
    username:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    enterDate:{
        type:Date,
        default:new Date(),
    },
    status:{
        type:String,
        default:'Active'
    }
})

module.exports=mongoose.model('regsitration',regSchema)