const serviceTable=require('../models/services')


exports.services=async(req,res)=>{
    try{
    const message=req.params.mess
    if(message=='asc'){
        var data=await serviceTable.find().sort({postedDate:1})
    }else if(message=='desc'){
    var data=await serviceTable.find().sort({postedDate:-1})
    }else if(req.query.search!=undefined){
        var data=await serviceTable.find({status:req.query.search}).sort({postedDate:-1})
    }else if(req.query.search==undefined){
        var data=await serviceTable.find().sort({postedDate:-1})  

    }
    else{ 
        var data=await serviceTable.find().sort({postedDate:-1})  
    }  
    const username =req.session.loginname
    const tservice=await serviceTable.find().count()
    const pservice=await serviceTable.find({status:'Published'}).count()
    const unservice=await serviceTable.find({status:'Unpublished'}).count()
 
    res.render('admin/services.ejs',{username,message,data,tservice,pservice,unservice})
}catch(error){
    console.log(error.message)
    //res.render("admin/error.ejs")
}
}


exports.serviceform=(req,res)=>{
    const message=req.params.mess
    const username =req.session.loginname
    res.render('admin/serviceform.ejs',{username,message})
}


exports.serviceadd=(req,res)=>{
    const{title,desc,mdesc}=req.body
    if(req.file){
        let filename=req.file.filename
        var newRecord=new serviceTable({title:title,desc:desc,mdesc:mdesc,img:filename})
    }else{
        let filename=''
        var newRecord=new serviceTable({title:title,desc:desc,mdesc:mdesc,img:filename})
    }
        newRecord.save()
        res.redirect('/admin/services/Successfully Data inserted!!')
        //console.log(newRecord)
}

exports.delete=async(req,res)=>{
    const id=req.params.id
    await serviceTable.findByIdAndDelete(id)
    res.redirect('/admin/services/successfully Deleted')
}



exports.update=async(req,res)=>{
    const id=req.params.id
    const currentstatus=req.params.status
    let newstatus=null
    if(currentstatus=='Published'){
        newstatus='Unpublished'
    }else{
        newstatus='Published'
    }
    await serviceTable.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/services/Status has been updated')


}

exports.singledata=async(req,res)=>{
    const id=req.params.id
    const data=await serviceTable.findById(id)
    res.render('servicedetails.ejs',{data})

}