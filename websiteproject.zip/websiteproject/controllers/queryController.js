const queryTable=require('../models/query')
const nodemailer=require('nodemailer')


exports.insert=(req,res)=>{
    const{email,query}=req.body
    const newdata=new queryTable({email:email,query:query})
    newdata.save()
    res.render('message.ejs')
}

exports.query=async(req,res)=>{
    const username =req.session.loginname
    const data=await queryTable.find().sort({status:-1})
    const message=req.params.mess
    //console.log(data)
       res.render('admin/query.ejs',{username,data,message})
   }

   exports.emailform=(req,res)=>{
    const email=req.params.email
    const query=req.params.query
    const username =req.session.loginname
    res.render('admin/emailform.ejs',{username,email,query})
}

exports.emailsend=async(req,res)=>{
    const id=req.params.id
    const{emailto,emailfrom,sub,body}=req.body
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user:'rtestexpress@gmail.com',
          pass:'cbfhvatynadixfuv',
        },
      });
      await transporter.sendMail({
        from:'rtestexpress@gmail.com', // sender address
        to:emailto, // list of receivers
        subject:sub, // Subject line
        text:body, // plain text body
        //html: "<b>Hello world?</b>", // html body
      });
      await queryTable.findByIdAndUpdate(id,{status:'Replied'})
      res.redirect('/admin/query/Successfully Sent')
}