const regsitrationTable=require('../models/registration')
const bcrypt=require('bcrypt')
let message=''
let color=''
let mess='jj'

exports.loginpage=(req,res)=>{
    let error=''
    res.render('admin/login.ejs',{error})
}

exports.logincheck=async(req,res)=>{
    let error=null
    const{us,pass}=req.body
    if(us=='' || pass==''){
        error='please fill username and password!!'
        res.render('admin/login.ejs',{error})
    }else{
    const usercheck=await regsitrationTable.findOne({username:us})
    
    if(usercheck!=null){
       let comparpass=await bcrypt.compare(pass,usercheck.password) 
      
        if(comparpass){
            req.session.isAuth=true
            req.session.loginname=us
            res.redirect('/admin/dashboard')
        }else{
            error='wrong password'
           
            res.render('admin/login.ejs',{error})
        }
    }else{
        error='Wrong username'
       // res.send("Wrong username")
        res.render('admin/login.ejs',{error})
    }
}
}

exports.dashboard=(req,res)=>{
    const username=req.session.loginname

    res.render('admin/dashboard.ejs',{username,mess})
}

exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')
}





exports.testurl=async(req,res)=>{
    let a='123'
    const converteda= await bcrypt.hash(a,10)
    const newrecord=new regsitrationTable({username:'admin',password:converteda})
    newrecord.save()
}

//test url




