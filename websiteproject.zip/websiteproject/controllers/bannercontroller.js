const bannerTable=require('../models/banner')

exports.banner=async(req,res)=>{
   const message=req.params.mess
    const username=req.session.loginname
      const data  =await bannerTable.findOne()
    res.render('admin/banner.ejs',{username,data,message})
}


exports.updateform=async(req,res)=>{
    const username=req.session.loginname
    const id=req.params.id
      const data=await bannerTable.findById(id)
    res.render('admin/bannerform.ejs',{username,data})
}

exports.upddate=async(req,res)=>{
  const username=req.session.loginname
  const id=req.params.id
  const data=await bannerTable.findById(id)
  const{btitle,bdesc,mdesc}=req.body
  if(req.file){
    const fileName=req.file.filename
 await bannerTable.findByIdAndUpdate(id,{title:btitle,desc:bdesc,mdesc:mdesc,img:fileName})
  }else{
    await bannerTable.findByIdAndUpdate(id,{title:btitle,desc:bdesc,mdesc:mdesc})

  }
 res.redirect(`/admin/banner/Successfully Update`)
  //res.render('admin/bannerform.ejs',{username,data,mess:'succfully Update'})

}

exports.bannermoredeatils=async(req,res)=>{
    const data=await bannerTable.findOne()
  res.render('bannerdetails.ejs',{data})
}