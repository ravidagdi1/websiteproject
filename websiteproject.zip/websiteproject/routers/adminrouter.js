const router=require('express').Router()
const regc=require('../controllers/regsitrationcongtroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/serviceController')
const queryc=require('../controllers/queryController')
const handlelogin=require('../middleware/logincheck')
const upload=require('../middleware/multer')
function serviceformvalidation(req,res,next){
    let message=''
    const username =req.session.loginname
const{title,desc,mdesc}=(req.body)
if(title==''){
    message='Please fill Title'
}else if(desc==''){
  message='Please fill descrption'
}else if(mdesc==''){
    message='Please fill More Deatils'
}else{
next()
}
res.redirect(`/admin/serviceadd/${message}`)
//res.render('admin/serviceform.ejs',{message,username})
}



router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/dashboard',handlelogin,regc.dashboard)
router.get('/logout',regc.logout)
router.get('/banner/:mess',handlelogin,bannerc.banner)
router.get('/bannerupdate/:id',handlelogin,bannerc.updateform)
router.post('/bannerupdate/:id',upload.single('img'),bannerc.upddate)
router.get('/services/:mess',handlelogin,servicec.services)
router.get('/serviceadd/:mess',handlelogin,servicec.serviceform)
router.post('/serviceadd/:mess',upload.single('img'),serviceformvalidation,servicec.serviceadd)
router.get('/servicedelete/:id',handlelogin,servicec.delete)
router.get('/ssttausupdate/:id/:status',handlelogin,servicec.update)
router.get('/query/:mess',handlelogin,queryc.query)
router.get('/emailreply/:id/:email/:query',handlelogin,queryc.emailform)
router.post('/emailreply/:id/:email/:query',queryc.emailsend)









///test url
router.get('/testurl',regc.testurl)



module.exports=router