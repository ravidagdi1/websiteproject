const router=require('express').Router()
const regc=require('../controllers/regsitrationcongtroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/serviceController')
const queryc=require('../controllers/queryController')


router.get('/bannerdetails',bannerc.bannermoredeatils)
router.get('/servicedetails/:id',servicec.singledata)
router.post('/queryform',queryc.insert)



module.exports=router