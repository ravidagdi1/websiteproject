const router=require('express').Router()
const bannerTable=require('../models/banner')
const servicec=require('../controllers/serviceController')
const queryc=require('../controllers/queryController')
const serviceTable=require('../models/services')



router.get('/',async(req,res)=>{
    const data=await bannerTable.findOne()
    const serviceData=await serviceTable.find({status:'Published'})
     res.render('index.ejs',{data,serviceData})
 })



module.exports=router