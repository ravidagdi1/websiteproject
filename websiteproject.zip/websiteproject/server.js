const express=require('express')//function
const app=express()
require('dotenv').config()
app.use(express.urlencoded({extended:false}))
const mongoose=require('mongoose')//module
mongoose.connect('mongodb://127.0.0.1:27017/730knodeproject')
const session=require('express-session')
const morgan=require('morgan')
const adminRouter=require('./routers/adminrouter')
const userRouter=require('./routers/userrouter')
const homeRouter=require('./routers/home')


app.use(session({
    secret:'ravi',
    resave:false,
    saveUninitialized:false,
    cookie:{maxAge:1*1000*60*60*24*365}
}))
app.use(morgan('dev'))
app.use(homeRouter)
app.use('/users',userRouter)
app.use('/admin',adminRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT ||5000,()=>{console.log(`server is running on port ${process.env.PORT}`)})